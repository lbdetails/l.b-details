# L.B Details

Tienda de flores – estructura web básica.

## Para empezar

1. Clona el repositorio:
   ```
   git clone https://github.com/tu_usuario/l-b-details.git
   ```
2. Abre `index.html` en tu navegador.
3. Reemplaza imágenes y ajusta estilos según prefieras.
4. Para ver cambios en tiempo real, puedes usar extensiones de Live Server o edición directa.

## Publicación futura (opcional)

- Puedes conectar a Netlify o Vercel cuando estés lista.
