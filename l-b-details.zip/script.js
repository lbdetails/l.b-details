let carrito = [];
function agregarAlCarrito(nombre, precio) {
  carrito.push({nombre, precio});
  alert(nombre + ' ha sido añadido al carrito.');
}
// Podés agregar seguimiento, carrito persistente, etc.
